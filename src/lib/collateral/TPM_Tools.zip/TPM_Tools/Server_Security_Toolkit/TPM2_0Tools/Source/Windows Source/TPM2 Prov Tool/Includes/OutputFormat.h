#ifndef _OUTPUT_FORMAT
#define _OUTPUT_FORMAT

// SFI - Added ifdef WIN32 
#ifdef WIN32
#define color(a) UefiSetConsoleTextColor(a)
#else
#define color(a) gST->ConOut->SetAttribute(gST->ConOut, a)
#endif

#define titColor color(EFI_WHITE)
#define errColor color(EFI_LIGHTRED)               
#define warColor color(EFI_YELLOW);
#define infColor color(EFI_LIGHTBLUE)
#define norColor color(EFI_LIGHTGRAY)
#define okColor color(EFI_GREEN)

//depricated
//void ScreenLine(int iLineCnt);
void DumpHexValue (CHAR16 *pMsgStr, UINT8 *pu8Source, UINT32 u32DataSize);
void PadSpace(CHAR16 * strSource, UINT32 u32PadLen);
void /*printBinary*/DumpBinary(UINT8 *pByte, UINT32 u32ByteCnt, UINT32 u32BytePerRowCnt, UINT32 u32SpcShftRow1, UINT32 u32SpcShftRowOtr);


#endif //_OUTPUT_FORMAT

