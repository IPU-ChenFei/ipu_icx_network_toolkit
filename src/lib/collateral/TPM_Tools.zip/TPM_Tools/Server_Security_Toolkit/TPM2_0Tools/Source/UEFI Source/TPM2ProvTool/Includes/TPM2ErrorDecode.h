#include "Uefi.h"
#include "Uefilib.h"
#include "MemoryAllocationLib.h" //For AllocateZeroPool
#include "Base.h" //For OFFSET_OF Macro
#include "BaseMemoryLib.h"

#include "WaitAndStatusCheck.h"
#include "OutputFormat.h"
#include "Debug.h"

//#include "Tpm20_Types.h"

//Bit definitions
#define BIT_0				0x1
#define BIT_1				0x2
#define BIT_2				0x4
#define BIT_3				0x8
#define BIT_4				0x10
#define BIT_5				0x20
#define BIT_6				0x40
#define BIT_7				0x80
#define BIT_8				0x100
#define BIT_9				0x200
#define BIT_10				0x400
#define BIT_11				0x800
#define BIT_12				0x1000
#define BIT_13				0x2000
#define BIT_14				0x4000
#define BIT_15				0x8000

CHAR16 *ptr;
CHAR16 *ErrorText0[128];
CHAR16 *ErrorText1[39];
CHAR16 *WarnText[128];

void formatZeroErrors();
void formatOneErrors();
void warnings();
void decodeTpm20ErrorCode(UINT32 TPM2ReturnCode);