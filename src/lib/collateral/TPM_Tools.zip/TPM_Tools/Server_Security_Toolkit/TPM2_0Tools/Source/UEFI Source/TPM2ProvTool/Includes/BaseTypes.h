/*(Copyright)

        Microsoft Copyright 2009, 2010, 2011, 2012, 2013
        Confidential Information

*/
/*(Auto)

    Created by TpmStructures Version 02.00.00 Feb 1, 2013
    This file created on Oct 18, 2013, 10:18:11PM 

*/

#ifndef _BASETYPES_H
#define _BASETYPES_H

#include "stdint.h"

// NULL definition
#ifndef         NULL
#define         NULL        (0)
#endif

typedef  uint8_t            UINT8;
typedef  uint8_t            BYTE;
typedef  int8_t             INT8;
typedef  int                BOOL;
typedef  uint16_t           UINT16;
typedef  int16_t            INT16;
typedef  uint32_t           UINT32;
typedef  int32_t            INT32;
typedef  uint64_t           UINT64;
typedef  int64_t            INT64;

	
typedef struct {
    UINT16        size;
    BYTE          buffer[1];
} TPM2B;

#endif
