#ifndef _DEBUG_LOG
#define _DEBUG_LOG

#include "Uefi.h"
#include "Uefilib.h"

extern UINT32 g_DebugMask;

CHAR16 gch16FILE[20];

//#ifdef DEBUG_BUILD	//VP: -m option is both for DEBUG and RELEASE build
//#define DEBUG_LOG(_DbgMsg_) Print _DbgMsg_; 

#define	DEBUG_LOG(_a_)	\
	{					\
		if ( g_DebugMask & 0x20 ) \
		{	\
			Print(L"** %s %d **\n", gch16FILE, __LINE__); \
		}						\
		if ( g_DebugMask & 0x40) \
		{							\
			Print _a_;			\
		}							\
	}

//#else 
//#define DEBUG_LOG(_DbgMsg_)
//#endif //DEBUG_BUILD

#endif //_DEBUG_LOG