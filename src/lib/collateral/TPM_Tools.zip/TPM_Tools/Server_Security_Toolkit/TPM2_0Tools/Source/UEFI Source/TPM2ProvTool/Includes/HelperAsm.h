#ifndef _HELPER_ASM
#define _HELPER_ASM
//Assembly helpers
void ByteSwapDWord(UINT32 *pData);
void RotateLeft(UINT32 *pData, UINT8 u8NumBits);
UINT32 UpperDW(UINT64 *pData);

#endif //_HELPER_ASM