#include "Uefi.h"
#include "TPM20Info.h"
#include "OutputFormat.h"



BOOLEAN packStartAuthSession(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER	*cmdHeader, T2P_HANDLE_AREA	*cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
						T2T_SESSION_DEF_FILE *sDef, T2P_CONFIG_FILE *sCfg);
						
BOOLEAN packPolicyLocality(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
						 T2T_POLICY_DEF_FILE *pDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber);
						
BOOLEAN packPolicyDigest(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
						T2T_SESSION_DEF_FILE *sDef, T2P_CONFIG_FILE *sCfg);
						
BOOLEAN packIndexDelete(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
						T2T_NV_DEF_FILE *iDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber);
						
BOOLEAN packIndexDeleteSpecial(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
						T2T_NV_DEF_FILE *iDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber, UINT8 sessionNumber2);
						
BOOLEAN packIndexDefine(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
						T2T_NV_DEF_FILE *iDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber);
						
BOOLEAN packIndexWrite(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
						T2T_NV_DEF_FILE *iDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber, UINT32 handle0);
						
BOOLEAN packNvRead(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
	T2T_NV_DEF_FILE *iDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber, UINT32 handle0);

BOOLEAN packPolicyRestart(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
						T2P_CONFIG_FILE *sCfg);
						
BOOLEAN assertPolicy(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
						T2T_POLICY_DEF_FILE *pDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber);
						
BOOLEAN packPolicyOR(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_POLICY_DEF_FILE *pDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber);

BOOLEAN packPolicyCpHash(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_POLICY_DEF_FILE *pDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber);

BOOLEAN packPolicyNameHash(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_POLICY_DEF_FILE *pDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber);
					
BOOLEAN packPolicyCommandCode(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_POLICY_DEF_FILE *pDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber);
					
BOOLEAN packPolicySecret(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_POLICY_DEF_FILE *pDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber, UINT8 sessionNumber2);
					
BOOLEAN packPolicySigned( T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_POLICY_DEF_FILE *pDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber );
					
BOOLEAN packPolicyNV( T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_POLICY_DEF_FILE *pDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber );
					
BOOLEAN packPolicyAuthorize( T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_POLICY_DEF_FILE *pDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber );

BOOLEAN packPolicyNvWitten(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_POLICY_DEF_FILE *pDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber);
					
BOOLEAN packSetPrimaryPolicy(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_POL_SET_FILE *pSet, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber);
					
BOOLEAN packHierarchyChangeAuth(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber, UINT32 hierarchy, CHAR16 *dataFile );

BOOLEAN packTPM2Clear(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber);

BOOLEAN packTPM2ClearControl(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber, UINT8 OwnerClearDisable);

BOOLEAN packTPM2DaLockReset(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber);

BOOLEAN packTPM2HMAC(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber, UINT8 *rawData, UINT64 dataSize );

BOOLEAN packTPM2HashSequenceStart(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2P_CONFIG_FILE *sCfg );

BOOLEAN packTPM2HashSequenceUpdate(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2P_CONFIG_FILE *sCfg, UINT8 handleNumber, UINT8 *rawData, UINT64 dataSize );

BOOLEAN packTPM2HashSequenceComplete(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2P_CONFIG_FILE *sCfg, UINT8 handleNumber );

BOOLEAN packTPM2NVWriteLock(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_NV_DEF_FILE *iDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber, UINT32 handle0 );

BOOLEAN packTPM2NVChangeAuth(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_NV_DEF_FILE *iDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber, UINT32 authNumber );

BOOLEAN packTPM2CreatePrimary(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_K_DEF_FILE *kDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber );

BOOLEAN packTPM2Create(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_K_DEF_FILE *kDef, T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber, UINT8 handleNumber );

BOOLEAN packTPM2LoadExternal(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					UINT32	hierarchy, UINT8 *inSensitive, UINT64 inSensitiveSize, UINT8 *outPublic, UINT64 dataSize );

BOOLEAN packTPM2Load(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2P_CONFIG_FILE *sCfg, UINT8 *inPrivate, UINT64 inPrivateSize, UINT8 *inPublic, UINT64 inPublicSize, UINT8 handleNumber, UINT8 sessionNumber );

BOOLEAN packTPM2Execute(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2T_CDEF_FILE *cDef, T2P_CONFIG_FILE *sCfg, BOOLEAN sessions, UINT64 *sessionNumber );

BOOLEAN packTPM2HierarchyControl(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2P_CONFIG_FILE *sCfg, UINT32 authhandle, UINT8 sessionNumber, UINT32 enableHierarchy, UINT8 hierarchyState);

BOOLEAN packTPM2PolicyPCR(T2P_CMD_SGL *packedCmd, T2P_CMD_HEADER *cmdHeader, T2P_HANDLE_AREA *cmdHandles, T2P_AUTHAREA *cmdAuthArea, T2P_CP_BUF *cmdParamArea, 
					T2P_CONFIG_FILE *sCfg, UINT8 sessionNumber, UINT8 digestIndex );