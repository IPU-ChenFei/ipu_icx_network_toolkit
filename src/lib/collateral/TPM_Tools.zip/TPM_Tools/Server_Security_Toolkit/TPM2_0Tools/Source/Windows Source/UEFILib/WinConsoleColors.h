#ifndef __COLORS_H_
#define __COLORS_H_

#include <Windows.h>

enum WinConsoleColor
{
	WinConsoleColor_Black=0,
	WinConsoleColor_DarkBlue=1,
	WinConsoleColor_DarkGreen=2,
	WinConsoleColor_DarkAqua=3,
	WinConsoleColor_DarkRed=4,
	WinConsoleColor_DarkPurple=5,
	WinConsoleColor_DarkYellow=6,
	WinConsoleColor_DarkWhite=7,
	WinConsoleColor_Gray=8,
	WinConsoleColor_Blue=9,
	WinConsoleColor_Green=10,
	WinConsoleColor_Aqua=11,
	WinConsoleColor_Red=12,
	WinConsoleColor_Purple=13,
	WinConsoleColor_Yellow=14,
	WinConsoleColor_White=15
};

#endif // __COLORS_H_