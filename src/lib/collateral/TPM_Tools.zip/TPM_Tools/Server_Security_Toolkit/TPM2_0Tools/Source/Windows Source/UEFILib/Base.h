/*
 * This file is here to satisfy the compiler.
 * All of the function definitions are in Uefi.h
 * In the future we could move definitions to this file to match the EDK2
 */

#include "Uefi.h"