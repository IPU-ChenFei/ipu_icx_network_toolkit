// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once
#include <windows.h>
//#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#include <conio.h>
#include <winsock.h>
#pragma comment(lib,"ws2_32.lib")
//#include "ftd2xx.h"

//Sim socket
SOCKET SocketPlatform;
SOCKET SocketTPM;
struct hostent *host;



//MS TPM 2.0 Simulator TCP/IP Ports
#define DEFAULT_TPM_PLATFORM_PORT 2322
#define DEFAULT_TPM_COMMAND_PORT 2321

//Socket defines
#define SD_SEND		0	//Socket can only send
#define	SD_RECIEVE	1	//Socket can only recieve
#define	SD_BOTH		2	//Socket can no longer send or recieve

// TPM Commands.  
// All commands acknowledge processing by returning a UINT32 == 0 except where noted
#define TPM_SIGNAL_POWER_ON         1
#define TPM_SIGNAL_POWER_OFF        2
#define TPM_SIGNAL_PHYS_PRES_ON     3
#define TPM_SIGNAL_PHYS_PRES_OFF    4
#define TPM_SIGNAL_HASH_START       5
#define TPM_SIGNAL_HASH_DATA        6           // {UINT32 BufferSize, BYTE[BufferSize] Buffer}
#define TPM_SIGNAL_HASH_END         7
#define TPM_SEND_COMMAND            8           // {BYTE Locality, UINT32 InBufferSize, BYTE[InBufferSize] InBuffer} -> 
//                                                          {UINT32 OutBufferSize, BYTE[OutBufferSize] OutBuffer}
#define TPM_SIGNAL_CANCEL_ON        9
#define TPM_SIGNAL_CANCEL_OFF       10

#define TPM_SIGNAL_NV				11
#define TPM_SIGNAL_NV_OFF			12
#define TPM_SIGNAL_KEY_CACHE_ON		13
#define TPM_SIGNAL_Key_CACHE_OFF	14
#define TPM_REMOTE_HANDSHAKE		15
#define	TPM_SetAlternativeResult 	16
#define TPM_SessionEnd				20
#define TPM_Stop 					21
#define TPM_TEST_FAILURE_MODE		30

//#define TPM_SHUTDOWN                11