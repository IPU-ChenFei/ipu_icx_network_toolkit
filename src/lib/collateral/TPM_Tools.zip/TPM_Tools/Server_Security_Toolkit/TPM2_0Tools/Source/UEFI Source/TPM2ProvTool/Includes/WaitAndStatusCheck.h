#ifndef _WAIT_AND_STATUS_CHECK
#define _WAIT_AND_STATUS_CHECK

//Function pointer to status check function
/*
	Return: 0 if timeout and non-zero is status is successfull
*/
typedef UINT8 (*STATUS_CHECK_PROC_PTR) (void *pBuffer);

/*
	Return: 0 if timeout and non-zero is status is successfull
*/
UINT8 WaitAndStatusCheck(UINT32 u32WaitMS, STATUS_CHECK_PROC_PTR pStatusCheckProc, void *pBuffer);
void ASMDelay1MS();
void ASMIODelay();
#endif //_WAIT_AND_STATUS_CHECK