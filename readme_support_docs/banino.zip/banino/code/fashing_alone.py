import sys
import ctypes
import time
import os
dir_path = os.path.dirname(os.path.realpath(__file__))
dll_path = (r'C:\banino\code\BaninoControlCenter\x64\ladybird.dll')
#power_cmd = "cd {} & SxState.exe".format(os.path.join(dir_path, "Banino_SXState"))
bin_file = r"C:\ifwi\ifwi.bin"
ladybird = ctypes.cdll.LoadLibrary(dll_path)

def conect_relay(relay_num, relay_port):
    try:
        relay_state = ladybird.GetRelayState(1, relay_num, relay_port)
        if relay_state == 1:
            print("relay is ready connect. nothing to do")
            return True
        else:
            ladybird.SetRelayState(1, relay_num, relay_port, 1)
            time.sleep(1)
            relay_state = ladybird.GetRelayState(1, relay_num, relay_port)
            if relay_state == 1:
                print("connect relay successful")
                return True
            else:
                print("connect relay fail")
                return False
    except Exception, ex:
        print(ex)
        return False
        
def disconnect_relay(relay_num, relay_port):
    try:
        relay_state = ladybird.GetRelayState(1, relay_num, relay_port)
        if relay_state == 0:
            print("relay is ready disconnect. nothing to do")
            return True
        else:
            ladybird.SetRelayState(1, relay_num, relay_port, 0)
            time.sleep(1)
            relay_state = ladybird.GetRelayState(1, relay_num, relay_port)
            if relay_state == 0:
                print("disconnect relay successful")
                return True
            else:
                print("disconnect relay fail")
                return False
    except Exception, ex:
        print(ex)
        return False

def flash_chip_writing():

    if(image_path==''):
        print(">> Image Path Is Not Specified <<")
        return False
    if conect_relay(1, 7) != True:
        print("connect VCC relay fail, please check the hard connection")
        return False
    try:
        lbHandle = ladybird.OpenByBaninoNumber(1, 1)
        flashDevice = "0"
        flashStartAddress = 0
        filePath = ctypes.create_string_buffer(image_path)
        writeSize = os.path.getsize(filePath.value)
        print("{0} object, size {1}".format(filePath, writeSize))
        fileOffset = 0
        result = 1
        result = ladybird.FlashReady(lbHandle, ctypes.c_char(flashDevice))
        if result != 0:
            print("FlashReady:{}, >> Bios chip NOT DETECTED <<".format(result))
            return False
        else:
            print("FlashReady:{}, ----> Bios Chip Have Been Detected <----".format(result))

        
        print("===========> Start to Erase Flash Chip <===========")
        result = ladybird.FlashErase(lbHandle, ctypes.c_char(flashDevice))
        if result != 0:
            print("FlashErase:{}, Erase bios chip fail".format(result))
            return False
        else:
            print("FlashErase:{}, Erase bios chip pass".format(result))
        
        
            
        print("===========> Start to Write IFWI Image to Chip <==========")
        result = ladybird.FlashWriteFile(lbHandle, ctypes.c_char(flashDevice), flashStartAddress, writeSize, filePath, fileOffset)
        if result != 0:
            print("FlashWriteFile:{}, Burning bios chip fail".format(result))
            return False
        else:
            print("FlashWriteFile:{}, Burning bios chip pass".format(result))

            
        print("===========> Start to Veritfy write binary is correct or Not <==========")
        result = ladybird.FlashVerifyFile(lbHandle, ctypes.c_char(flashDevice), flashStartAddress, writeSize, filePath, fileOffset)
        if result != 0:
            print("FlashVerifyFile:{}, Verify BIOS chip fail".format(result))
            return False
        else:
            print("FlashVerifyFile:{}, Verify BIOS chip pass".format(result))

        print("Flash BIOS successful")
        ladybird.Close(lbHandle)
        return True
        
    except Exception, ex:
        print(ex)
        return False
    finally:
        if disconnect_relay(1, 7) != True:
            print("disconnect VCC relay fail")
            return False
