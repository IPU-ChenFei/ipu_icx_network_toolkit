#Author Suresh Sakthi
import os
import time
import sys
import ctypes
import time
#from common2.lib.globals.return_code import *
#from common2.lib.private import sparklogger
#from common2.lib.configuration import configuration
##dir_path = os.path.dirname(os.path.realpath(__file__))
##dll_path = os.path.join(dir_path, r'BaninoControlCenter\x32\ladybird.dll')
##power_cmd = "cd {} & SxState.exe".format(os.path.join(dir_path, "Banino_SXState"))
##bin_file = r"C:\Users\sys_piauto\Desktop\banino\code\PLYXCRB.86B.BR.64.2018.38.3.03.0614_LBG_SPS.bin"
##ladybird = ctypes.cdll.LoadLibrary(dll_path)
##
##dir_path = os.path.dirname(os.path.realpath(__file__))
##print(dir_path)
#dll_path = os.path.join(dir_path, r'BaninoControlCenter\x32\ladybird.dll')

#power_cmd = "cd {} & SxState.exe".format(os.path.join(dir_path, "Banino_SXState"))
#print(power_cmd)
##dll_path=r'C:\Users\sys_piauto\Desktop\banino\code\BaninoControlCenter\x32\ladybird.dll'
##power_cmd =r"cd C:\Users\sys_piauto\Desktop\banino\code\Banino_SXState & SxState.exe"
##print(power_cmd)
##ladybird = ctypes.cdll.LoadLibrary(dll_path)

##CONTROL_BOX_TO_USE = configuration.get_value('Hardware Configuration', 'control_box')
##if CONTROL_BOX_TO_USE == 'banino':
dll_path=r'C:\banino\code\Banino\x64\ladybird.dll'
power_cmd =r"cd C:\banino\code\Banino_SXState & SxState.exe"
ladybird = ctypes.cdll.LoadLibrary(dll_path)

def get_power_status_by_banino():
        output = os.popen(power_cmd).read()
        power_status = output.strip()
        print(power_status)
        if(power_status == "S0"):
            power_list=[0,0]
        elif(power_status == "S5"):
            power_list=[0,3]
        elif(power_status == "G3"):
             power_list=[0,0]
        elif(power_status == "S4"):
             power_list=[0,3]
        elif(power_status == "S3"):
             power_list=[0,3]
        print(power_list)
        print(r'_get_power_voltages success end {0}'.format(power_list))
        if power_status.upper() not in ["G3", "S3", "S4", "S", "S0"]:
            print("Get error power status: {}".format(power_status))
            return False
        else:
            return power_status

def conect_relay(relay_num, relay_port):
        try:
            relay_state = ladybird.GetRelayState(1, relay_num, relay_port)
            if relay_state == 1:
                print("relay is ready connect. nothing to do")
                return True
            else:
                ladybird.SetRelayState(1, relay_num, relay_port, 1)
                time.sleep(1)
                relay_state = ladybird.GetRelayState(1, relay_num, relay_port)
                if relay_state == 1:
                    print("connect relay successful")
                    return True
                else:
                    print("connect relay fail")
                    return False
        except Exception as ex:
            print("error {0}".format(ex))
            return False

def disconnect_relay(relay_num, relay_port):
        try:
            relay_state = ladybird.GetRelayState(1, relay_num, relay_port)
            if relay_state == 0:
                print("relay is ready disconnect. nothing to do")
                return True
            else:
                ladybird.SetRelayState(1, relay_num, relay_port, 0)
                time.sleep(1)
                relay_state = ladybird.GetRelayState(1, relay_num, relay_port)
                if relay_state == 0:
                    print("disconnect relay successful")
                    return True
                else:
                    print("disconnect relay fail")
                    return False
        except Exception as ex:
            print(ex)
            return False

def clear_cmos_by_banino():

        try:
            if conect_relay(1, 3) != True:
                print("Short Clear COMS pin failed")
                return False
            else:
                print("Short Clear COMS pin pass")
            time.sleep(5)
            if disconnect_relay(1, 3) != True:
                print("Open Clear COMS pin failed")
                return False
            else:
                print("Open Clear COMS pin pass")
            print("Clear CMOS successful")
            return True
        except Exception as ex:
            print(ex)
            disconnect_relay(1, 3)
            return False

def hard_power_on_by_banino():
        try:
            num = 1
            port = 1
            ladybird.SetRelayState(1, num, port, 1)
            relay_state = ladybird.GetRelayState(1, num, port)
            print("short switch power button is {}".format(relay_state))
            time.sleep(1)
            ladybird.SetRelayState(1, num, port, 0)
            time.sleep(1)
            relay_state = ladybird.GetRelayState(1, num, port)
            print("short switch power button is {}".format(relay_state))
            return True
        except Exception as ex:
            print(ex)
            return False

def hard_power_off_by_banino():
        try:
            num = 1
            port = 1
            ladybird.SetRelayState(1, num, port, 1)
            relay_state = ladybird.GetRelayState(1, num, port)
            print("short switch power button is {}".format(relay_state))
            time.sleep(5)
            ladybird.SetRelayState(1, num, port, 0)
            time.sleep(1)
            relay_state = ladybird.GetRelayState(1, num, port)
            print("short switch power button is {}".format(relay_state))
            return True
        except Exception as ex:
            print(ex)
            return False

def switch_usb_to_sut_by_banino():
        try:
            print("start to switch usb disk to sut")
            lbHandle = ladybird.OpenByBaninoNumber(1, 2)
            ladybird.SetGpioDirection(lbHandle, 1, 0x6000000, 0x6000000)
            ladybird.SetGpioState(lbHandle, 1,  0x4000000 , 0x00)
            time.sleep(2)
            print("Short Relay_1_4")
            ladybird.SetGpioState(lbHandle, 1,  0x2000000, 0x00)
            ladybird.SetGpioState(lbHandle, 1, 0x4000000 , 0x4000000)
            time.sleep(5)
            # self.ladybird.close(lbHandle)
            return True
        except Exception as ex:
            print(ex)
            return False

def switch_usb_to_host_by_banino():
        try:
            print("start to switch usb disk to host")
            lbHandle = ladybird.OpenByBaninoNumber(1, 2)
            ladybird.SetGpioDirection(lbHandle, 1, 0x6000000, 0x6000000)
            ladybird.SetGpioState(lbHandle, 1,  0x4000000 , 0x00)
            time.sleep(2)
            print("Short Relay_1_4")
            ladybird.SetGpioState(lbHandle, 1,  0x2000000, 0x2000000)
            ladybird.SetGpioState(lbHandle, 1, 0x4000000 , 0x4000000)
            time.sleep(5)
            # self.ladybird.close(lbHandle)
            return True
        except Exception as ex:
            print(ex)
            return False

#switch_usb_to_sut_by_banino()
#switch_usb_to_host_by_banino()
#hard_power_off_by_banino()
#time.sleep(3)
hard_power_on_by_banino()
#get_power_status_by_banino()
#clear_cmos_by_banino()
