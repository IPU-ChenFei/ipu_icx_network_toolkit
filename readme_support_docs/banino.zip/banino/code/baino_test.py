import os
import time
import sys
import ctypes
import time
##from common2.lib.globals.return_code import *
##from common2.lib.private import sparklogger
##from common2.lib.private.soundwave import SoundWave, SoundWaveError
##from common2.lib.windows import execute, reboot
##from common2.lib.sut import enter_Windows
##from common2.lib import init, delete
##from common2.lib.private.state_transition import set_state
##from common2.lib.globals.state import *
import re

dir_path = os.path.dirname(os.path.realpath(__file__))
dll_path = os.path.join(dir_path, r'BaninoControlCenter\x32\ladybird.dll')
power_cmd = "cd {} & SxState.exe".format(os.path.join(dir_path, "Banino_SXState"))
bin_file = r"C:\Users\sys_piauto\Downloads\LinuxPackage\APP\Firmwares\IFWI\PLYXCRB.86B.BR.64.2018.21.2.09.1403_LBG_SPS.bin"

HIGHT_VOLTATE_VALUE = 3.6
LOW_VOLTAGE_VALUE = 2.4
ZOER_VOLTAGE_VALUE = 0.5
POWER_STATE_UNKNOWN = 'UNKNOWN'
CONTROL_BOX_ERROR = 'ControlBoxError'
VALUE_ERROR = 'ValueError'
HIGHT_VOLTAGE = "hight_voltage"
LOW_VOLTAGE = "low_voltage"
UNKNOWN_VOLTAGE = "unknown_voltage"
G3 = "G3"
S5 = "S5"
S0 = "S0"

count_sxstatus = 0

def get_usb_disk():
    usb_disk = []
    import wmi
    try:
        c = wmi.WMI()
        for physical_disk in c.Win32_DiskDrive():
            for partition in physical_disk.associators("Win32_DiskDriveToDiskPartition"):
                for logical_disk in partition.associators("Win32_LogicalDiskToPartition"):
                    time.sleep(5)
                    usbsize = long(physical_disk.Size)/1024/1024/1024
                    sparklogger.info("{0}, {1}".format(physical_disk.InterfaceType, usbsize))
                    if physical_disk.InterfaceType == "USB":
                        sparklogger.info("{} , {}".format(physical_disk.Caption, logical_disk.Caption))
                        usb_disk.append(logical_disk.Caption)
    except Exception as ex:
        sparklogger.error(ex)
    return usb_disk

def get_ad_value(pin):
    soundwave = SoundWave()
    try:
        powerlist = soundwave.get_ad_values([pin])
        if len(powerlist) == 1:
            power_value = powerlist[0]
        else:
            sparklogger.error("get error power: {}".format(powerlist))
            return UNKNOWN_VOLTAGE
        sparklogger.info("pin {0} value is {1}".format(pin, power_value))
        if LOW_VOLTAGE_VALUE <= power_value <= HIGHT_VOLTATE_VALUE:
            return HIGHT_VOLTAGE
        elif power_value <= ZOER_VOLTAGE_VALUE:
            return LOW_VOLTAGE
        else:
            return UNKNOWN_VOLTAGE
    except SoundWaveError:
        sparklogger.error('get Voltage error: {}'.format(CONTROL_BOX_ERROR))
        return UNKNOWN_VOLTAGE
    except ValueError:
        sparklogger.error('get Voltage error: {}'.format(VALUE_ERROR))
        return UNKNOWN_VOLTAGE
    except Exception,ex:
        sparklogger.error("get Voltage error {}".format(ex))
        return UNKNOWN_VOLTAGE
    finally:
        soundwave.close()

def check_power_state(pin, check_time, target):
    now_time = time.time()
    while time.time() - now_time <= check_time:
        if get_ad_value(pin) != target:
            sparklogger.error("get power status not right: {}".format())
            return False
    return True

def wait_for_power_state(pin, wait_for_time, target):
    now_time = time.time()
    while time.time()-now_time <= wait_for_time:
        if get_ad_value(pin) == target:
            sparklogger.info("successful detect power: {}".format(target))
            break
    else:
        sparklogger.error("fail to detect power: {}".format(target))
        return False
    return True

class Banino(object):
    def __init__(self, dll_path):
        self.dll_path = dll_path
        self.ladybird = ctypes.cdll.LoadLibrary(self.dll_path)

    def flash_bios_by_banino(self, bin_file):
        if self.conect_relay(1, 7) != RET_SUCCESS:
            sparklogger.error("connect VCC relay fail, please check the hard connection")
            return RET_ENV_FAIL
        try:
            sparklogger.info("start to do flash bios action")
            lbHandle = self.ladybird.OpenByBaninoNumber(1, 1)
            flashDevice = "0"
            flashStartAddress = 0
            filePath = ctypes.create_string_buffer(bin_file)
            # filePath = ctypes.create_string_buffer(b"C:\Users\sys_piauto\Downloads\LinuxPackage\APP\Firmwares\IFWI\PLYXCRB.86B.BR.64.2018.21.2.09.1403_LBG_SPS.bin")
            writeSize = os.path.getsize(filePath.value)
            sparklogger.info("{0} object, size {1}".format(filePath, writeSize))
            fileOffset = 0
            result = 1
            result = self.ladybird.FlashReady(lbHandle, ctypes.c_char(flashDevice))
            if result != 0:
                sparklogger.error("FlashReady:{}, Bios type not detect".format(result))
                return RET_TEST_FAIL
            else:
                sparklogger.info("FlashReady:{}, Bios type have detected".format(result))
            sparklogger.info("Start to Erase flash")
            result = self.ladybird.FlashErase(lbHandle, ctypes.c_char(flashDevice))
            if result != 0:
                sparklogger.error("FlashErase:{}, Erase bios chip fail".format(result))
                return RET_TEST_FAIL
            else:
                sparklogger.info("FlashErase:{}, Erase bios chip pass".format(result))
            sparklogger.info("Start to Write BIOS file to flash")
            result = self.ladybird.FlashWriteFile(lbHandle, ctypes.c_char(flashDevice), flashStartAddress, writeSize, filePath, fileOffset)
            if result != 0:
                sparklogger.error("FlashWriteFile:{}, Burning bios chip fail".format(result))
                return RET_TEST_FAIL
            else:
                sparklogger.info("FlashWriteFile:{}, Burning bios chip pass".format(result))
            sparklogger.info("Start to Veritfy write file")
            result = self.ladybird.FlashVerifyFile(lbHandle, ctypes.c_char(flashDevice), flashStartAddress, writeSize, filePath, fileOffset)
            if result != 0:
                sparklogger.error("FlashVerifyFile:{}, Verify BIOS chip fail".format(result))
                return RET_TEST_FAIL
            else:
                sparklogger.info("FlashVerifyFile:{}, Verify BIOS chip pass".format(result))
            if self.clear_cmos_by_banino() != RET_SUCCESS:
                return RET_TEST_FAIL
            sparklogger.info("Flash BIOS successful")
            self.ladybird.Close(lbHandle)
            return RET_SUCCESS
        except Exception, ex:
            sparklogger.error(ex)
            return RET_TEST_FAIL
        finally:
            if self.disconnect_relay(1, 7) != RET_SUCCESS:
                sparklogger.error("disconnect VCC relay fail")
                return RET_TEST_FAIL

    def switch_usb_to_sut_by_banino(self):
        try:
            sparklogger.info("start to do switch usb disk to sut action")
            lbHandle = self.ladybird.OpenByBaninoNumber(1, 2)
            self.ladybird.SetGpioDirection(lbHandle, 1, 0x6000000, 0x6000000)
            self.ladybird.SetGpioState(lbHandle, 1,  0x4000000 , 0x00)
            time.sleep(5)
            now_time = time.time()
            while time.time() - now_time <= 100:
                output = execute("python c:\BKCPkg\sutagent\get_usb_disk.py", timeout=30)
                print output.return_code, output.result_value
                if output.return_code != RET_SUCCESS:
                    sparklogger.warning("get SUT USB disk failed")
                    continue
                if "failed to find one use disk" in output.result_value[1]:
                    break
                break
            else:
                sparklogger.error("check USB disk failed")
                return RET_TEST_FAIL
            sparklogger.info("Short Relay_1_4")
            self.ladybird.SetGpioState(lbHandle, 1,  0x2000000, 0x00)
            self.ladybird.SetGpioState(lbHandle, 1, 0x4000000 , 0x4000000)
            time.sleep(5)
            now_time = time.time()
            while time.time() - now_time <= 100:
                output = execute("python c:\BKCPkg\sutagent\get_usb_disk.py", timeout=30)
                print output.return_code, output.result_value
                if output.return_code != RET_SUCCESS:
                    sparklogger.warning("get SUT USB disk failed")
                    continue
                if "successful to find one usb disk" in output.result_value[1]:
                    break
            else:
                sparklogger.error("check NONE USB disk failed")
                return RET_TEST_FAIL
            # self.ladybird.close(lbHandle)
            return RET_SUCCESS
        except Exception, ex:
            sparklogger.error(ex)
            return RET_TEST_FAIL

    def switch_usb_to_host_by_banino(self) :
        try:
            sparklogger.info("start to switch usb disk to host")
            lbHandle = self.ladybird.OpenByBaninoNumber(1, 2)
            self.ladybird.SetGpioDirection(lbHandle, 1, 0x6000000, 0x6000000)
            self.ladybird.SetGpioState(lbHandle, 1,  0x4000000 , 0x00)
            # time.sleep(5)
            now_time = time.time()
            while time.time() - now_time <= 30:
                if get_usb_disk() == []:
                    break
            else:
                sparklogger.error("check NONE USB disk failed")
                return RET_TEST_FAIL
            sparklogger.info("Short Relay_1_4")
            self.ladybird.SetGpioState(lbHandle, 1,  0x2000000, 0x2000000)
            self.ladybird.SetGpioState(lbHandle, 1, 0x4000000 , 0x4000000)
            now_time = time.time()
            while time.time() - now_time <= 600:
                usb_lable = get_usb_disk()
                sparklogger.info("Host USB DISK list: {}".format(usb_lable))
                if len(usb_lable) == 1:
                    check_file = os.path.join(usb_lable[0], os.sep, "USB_CHECK_FILE_FOR_BANINO")
                    if os.path.exists(check_file):
                        break
            else:
                sparklogger.error("Not found USB DISK on the host in 200 seconds")
                return RET_TEST_FAIL
            # time.sleep(5)
            # self.ladybird.close(lbHandle)
            return RET_SUCCESS
        except Exception, ex:
            sparklogger.error(ex)
            return RET_TEST_FAIL

    def hard_power_off_by_banino(self):
        try:
            num = 1
            port = 1
            sparklogger.info("start to do hard power off action")
            self.ladybird.SetRelayState(1, num, port, 1)
            power_statue = self.ladybird.GetRelayState(1, num, port)
            sparklogger.info("short switch power button is {}".format(power_statue))
            # time.sleep(5)
            if not wait_for_power_state(2, 2, HIGHT_VOLTAGE):
                return RET_TEST_FAIL
            if not check_power_state(2, 5, HIGHT_VOLTAGE):
                return RET_TEST_FAIL
            self.ladybird.SetRelayState(1, num, port, 0)
            power_statue = self.ladybird.GetRelayState(1, num, port)
            if not wait_for_power_state(2, 2, LOW_VOLTAGE):
                return RET_TEST_FAIL
            if not check_power_state(2,1, LOW_VOLTAGE):
                return RET_TEST_FAIL
            sparklogger.info("short switch power button is {}".format(power_statue))
            return RET_SUCCESS
        except Exception, ex:
            sparklogger.error(ex)
            return RET_TEST_FAIL

    def hard_power_on_by_banino(self):
        try:
            num = 1
            port = 1
            sparklogger.info("start to do hard power on action")
            self.ladybird.SetRelayState(1, num, port, 1)
            power_statue = self.ladybird.GetRelayState(1, num, port)
            sparklogger.info("short switch power button is {}".format(power_statue))
            if not wait_for_power_state(2, 2, HIGHT_VOLTAGE):
                return RET_TEST_FAIL
            if not check_power_state(2, 1, HIGHT_VOLTAGE):
                return RET_TEST_FAIL
            self.ladybird.SetRelayState(1, num, port, 0)
            power_statue = self.ladybird.GetRelayState(1, num, port)
            if not wait_for_power_state(2, 1, LOW_VOLTAGE):
                return RET_TEST_FAIL
            if not check_power_state(2, 1, LOW_VOLTAGE):
                return RET_TEST_FAIL
            sparklogger.info("short switch power button is {}".format(power_statue))
            return RET_SUCCESS
        except Exception, ex:
            sparklogger.error(ex)
            return RET_TEST_FAIL

    def reset_by_banino(self):
        try:
            num = 1
            port = 2
            sparklogger.info("start to do reset action")
            self.ladybird.SetRelayState(1, num, port, 1)
            power_statue = self.ladybird.GetRelayState(1, num, port)
            sparklogger.info("short switch power button is {}".format(power_statue))
            if not wait_for_power_state(13, 2, HIGHT_VOLTAGE):
                return RET_TEST_FAIL
            if not check_power_state(13, 1, HIGHT_VOLTAGE):
                return RET_TEST_FAIL
            self.ladybird.SetRelayState(1, num, port, 0)
            power_statue = self.ladybird.GetRelayState(1, num, port)
            if not wait_for_power_state(13, 1, LOW_VOLTAGE):
                return RET_TEST_FAIL
            if not check_power_state(13, 1, LOW_VOLTAGE):
                return RET_TEST_FAIL
            sparklogger.info("short switch power button is {}".format(power_statue))
            return RET_SUCCESS
        except Exception, ex:
            sparklogger.error(ex)
            return RET_TEST_FAIL

    def get_power_status_by_banino(self):
        sparklogger.info("start to do check power status action")
        global count_sxstatus
        output = os.popen(power_cmd).read()
        power_status = output.strip()
        count_sxstatus += 1
        sparklogger.info("start to do check power status action")
        if power_status.upper() not in ["G3", "S3", "S4", "S5", "S0"]:
            sparklogger.error("Get error power status: {}".format(power_status))
            return RET_INVALID_INPUT
        else:
            return power_status

    def clear_cmos_by_banino(self):
        try:
            sparklogger.info("start to do Clear CMOS action")
            if self.conect_relay(1, 3) != RET_SUCCESS:
                sparklogger.error("Short Clear COMS pin failed")
                return RET_TEST_FAIL
            else:
                sparklogger.info("Short Clear CMOS pin pass")
            if not wait_for_power_state(11, 2, HIGHT_VOLTAGE):
                return RET_TEST_FAIL
            if not wait_for_power_state(12, 2, LOW_VOLTAGE):
                return RET_TEST_FAIL
            if not check_power_state(11, 1, HIGHT_VOLTAGE):
                return RET_TEST_FAIL
            if self.disconnect_relay(1, 3) != RET_SUCCESS:
                sparklogger.error("Open Clear CMOS pin failed")
                return RET_TEST_FAIL
            else:
                sparklogger.info("Open Clear CMOS pin pass")
            if not wait_for_power_state(11, 2, LOW_VOLTAGE):
                return RET_TEST_FAIL
            if not wait_for_power_state(12, 2, HIGHT_VOLTAGE):
                return RET_TEST_FAIL
            if not check_power_state(12, 1, HIGHT_VOLTAGE):
                return RET_TEST_FAIL
            sparklogger.info("Clear CMOS successful")
            return RET_SUCCESS
        except Exception, ex:
            sparklogger.error(ex)
            self.disconnect_relay(1, 3)
            return RET_TEST_FAIL

    def conect_relay(self, relay_num, relay_port):
        try:
            power_statue = self.ladybird.GetRelayState(1, relay_num, relay_port)
            if power_statue == 1:
                sparklogger.info("relay is ready connect. nothing to do")
                return RET_SUCCESS
            else:
                self.ladybird.SetRelayState(1, relay_num, relay_port, 1)
                time.sleep(1)
                power_statue = self.ladybird.GetRelayState(1, relay_num, relay_port)
                if power_statue == 1:
                    sparklogger.info("connect relay successful")
                    return RET_SUCCESS
                else:
                    sparklogger.error("connect relay fail")
                    return RET_TEST_FAIL
        except Exception, ex:
            sparklogger.error(ex)
            return RET_TEST_FAIL

    def disconnect_relay(self, relay_num, relay_port):
        try:
            power_statue = self.ladybird.GetRelayState(1, relay_num, relay_port)
            if power_statue == 0:
                sparklogger.info("relay is ready disconnect. nothing to do")
                return RET_SUCCESS
            else:
                self.ladybird.SetRelayState(1, relay_num, relay_port, 0)
                time.sleep(1)
                power_statue = self.ladybird.GetRelayState(1, relay_num, relay_port)
                if power_statue == 0:
                    sparklogger.info("disconnect relay successful")
                    return RET_SUCCESS
                else:
                    sparklogger.error("disconnect relay fail")
                    return RET_TEST_FAIL
        except Exception, ex:
            sparklogger.error(ex)
            return RET_TEST_FAIL

def test_dc_power_on_off_and_clear_cmos_and_reset(test_banino):
    target_count = 100000
    count = 0
    while target_count >= count:
        sparklogger.info("====> start {} cycle test <====".format(count +1))
        if test_banino.hard_power_on_by_banino() != RET_SUCCESS:
            sparklogger.error("@ {} cycle hard power on failed".format(count))
            break
        if test_banino.hard_power_off_by_banino() != RET_SUCCESS:
            sparklogger.error("@ {} cycle hard power off failed".format(count))
            break

def test_usb_to_host_1w_cycle(test_banino):
    target_count = 10000
    count = 0
    while target_count >= count:
        sparklogger.info("====> start {} cycle test <====".format(count +1))
        if test_banino.switch_usb_to_host_by_banino() != RET_SUCCESS:
            sparklogger.info("@{} cycle switch USB disk to host failed".format(count))
            break
        count += 1
        sparklogger.info("====> end {} cycle test <====".format(count))

def test_usb_to_sut_1w_cycle(test_banino):
    init()
    try:
        set_state(State(ENV_STATE_ENTRY_MENU, POWER_STATE_S0))
        if enter_Windows(60) != RET_SUCCESS:
            return RET_TEST_FAIL
        target_count = 10000
        count = 0
        while target_count >= count:
            sparklogger.info("====> start {} cycle test <====".format(count +1))
            if test_banino.switch_usb_to_sut_by_banino() != RET_SUCCESS:
                sparklogger.info("@{} cycle switch USB disk to sut failed".format(count))
                time.sleep(120)
                set_state(State(ENV_STATE_ENTRY_MENU, POWER_STATE_S0))
                if enter_Windows(600) != RET_SUCCESS:
                    return RET_TEST_FAIL
                continue
            count += 1
            if count % 500 == 0:
                if reboot(600) != RET_SUCCESS:
                    sparklogger.error("reboot SUT failed")
                if enter_Windows(600) != RET_SUCCESS:
                    sparklogger.error("enter to windows failed")
            sparklogger.info("====> end {} cycle test <====".format(count))

    finally:
        delete()

class Sxstatus():
    def __init__(self, banino_obj):
        self.banino_obj = banino_obj

    def wait_power_status(self, target_power_status, wait_for_time):
        now_time = time.time()
        while time.time() - now_time <= wait_for_time:
            power_status = self.banino_obj.get_power_status_by_banino()
            sparklogger.info("detect power status is : {}".format(power_status))
            if power_status.upper() != target_power_status:
                continue
            else:
                break
        else:
            sparklogger.error("fail to detect power status {0} in {1} seconds".format(target_power_status, wait_for_time))
            return RET_TEST_FAIL
        return RET_SUCCESS

    def control_box_dc_power_action(self, press_time):
        soundwave = SoundWave()
        try:
            sparklogger.info("start press power button")
            if not soundwave.press_power_button():
                sparklogger.error("press power button failed")
                return RET_TEST_FAIL
            time.sleep(press_time)
            sparklogger.info("start release power button")
            if not soundwave.release_power_button():
                sparklogger.error("release power button failed")
                return RET_TEST_FAIL
            return RET_SUCCESS
        except Exception,ex:
            sparklogger.error(ex)
            return RET_TEST_FAIL
        finally:
            soundwave.close()

    def control_box_ac_power_action(self, status):
        soundwave = SoundWave()
        try:
            if status not in ["on", "off"]:
                sparklogger.error('input status not in ["on", "off"]')
                return RET_TEST_FAIL
            if status == "on":
                if not soundwave.ac_power_on():
                    sparklogger.error("ac power on failed")
                    return RET_TEST_FAIL
            elif status == "off":
                if not soundwave.ac_power_off():
                    sparklogger.error("ac power off failed")
                    return RET_TEST_FAIL
            else:
                return RET_TEST_FAIL
            return RET_SUCCESS
        except Exception,ex:
            sparklogger.error(ex)
            return RET_TEST_FAIL
        finally:
            soundwave.close()

def test_sxstatus_power_status_10w_cycle(test_banino):
    count = 0
    target_cycle = 100000
    global count_sxstatus
    sxstatus_obj = Sxstatus(test_banino)
    while count <= target_cycle:
        sparklogger.info("====> start {} cycle test <====".format(count +1))
        sparklogger.info("start AC power off SUT")
        if sxstatus_obj.control_box_ac_power_action("off") != RET_SUCCESS:
            break
        if sxstatus_obj.wait_power_status(G3, 10) != RET_SUCCESS:
            break
        time.sleep(2)
        sparklogger.info("start AC power on SUT")
        if sxstatus_obj.control_box_ac_power_action("on") != RET_SUCCESS:
            break
        if sxstatus_obj.wait_power_status(S0, 20) != RET_SUCCESS:
            break
        time.sleep(5)
        sparklogger.info("start DC power off SUT")
        if sxstatus_obj.control_box_dc_power_action(5) != RET_SUCCESS:
            time.sleep(5)
            if sxstatus_obj.control_box_dc_power_action(5) != RET_SUCCESS:
                break
        if sxstatus_obj.wait_power_status(S5, 10) != RET_SUCCESS:
            if sxstatus_obj.control_box_dc_power_action(5) != RET_SUCCESS:
                break
            if sxstatus_obj.wait_power_status(S5, 10) != RET_SUCCESS:
                break
        count += 1
        sparklogger.info("====> end {} cycle test <====".format(count))
        sparklogger.info("====> sxstatus read cycle is {}<====".format(count_sxstatus))
    sparklogger.info("====> sxstatus read cycle is {}<====".format(count_sxstatus))

if __name__ == "__main__":
    test_banino = Banino(dll_path)
    # if sys.argv[1] == "usbhost":
    #     test_banino.switch_usb_to_host_by_banino()
    # elif sys.argv[1] == "usbsut":
    #     test_banino.switch_usb_to_sut_by_banino()
    # elif sys.argv[1] == "dcon":
    #     test_banino.hard_power_on_by_banino()
    # elif sys.argv[1] == "dcoff":
    #     test_banino.hard_power_off_by_banino()
    # elif sys.argv[1] == "clear":
    #     test_banino.clear_cmos_by_banino()
    # elif sys.argv[1] == "flasbbios":
    #     if test_banino.flash_bios_by_banino(bin_file) != RET_SUCCESS:
    #         sparklogger.error("flash bios failed")
    #     else:
    #         sparklogger.info("successful flash bios pass")
    # elif sys.argv[1] == "power":
    #     test_banino.get_power_status_by_banino()
    test_sxstatus_power_status_10w_cycle(test_banino)
    test_dc_power_on_off_and_clear_cmos_and_reset()
    test_usb_to_sut_1w_cycle(test_banino)
    test_usb_to_host_1w_cycle(test_banino)
    sparklogger.info("Test End")
